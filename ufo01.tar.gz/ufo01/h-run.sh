#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf
. /hive-config/rig.conf
. /hive-config/wallet.conf

[[ -z $WORKER_NAME ]] && echo -e "${RED}No WORKER_NAME set${NOCOLOR}" && exit 1
[[ -z d7991f990d2950979dd442e5dac7376bfac514a9ca82b726b9d283f1 ]] && echo -e "${RED}No DWAL set${NOCOLOR}" && exit 1

#echo "================================"
#echo $CUSTOM_MINER
#echo $CUSTOM_LOG_BASENAME
#echo $CUSTOM_CONFIG_FILENAME
#echo "================================"
#echo $CUSTOM_USER_CONFIG
#echo $WORKER_NAME
#echo $EWAL
#echo "================================"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR
[[ -d $CUSTOM_LOG_BASEDIR ]] && [[ ! -f $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME ]] && cp -f /hive/custom/$CUSTOM_NAME/bisminer $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME && cp -f /hive/custom/$CUSTOM_NAME/bisminer.cfg $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME.cfg

echo "Starting Miner..."
echo $CUSTOM_LOG_BASENAME.stat
set +x
./UniMiner-linux -a x17r -o stratum+tcp://ufo.666pool.cn:7558 -u 2a22bf11ae808fb62a22db20962e60a7d15a78e482eceaa868a731ee1329f2fe17a.$WORKER_NAME -i 21 statfile=$CUSTOM_LOG_BASENAME.stat
